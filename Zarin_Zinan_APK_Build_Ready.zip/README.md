# Zarin & Zinan Android Project
এই project WebView ভিত্তিক। Android Studio-তে খুলে Build > Build APK(s) করলে APK তৈরি করা যাবে।
প্রথম সংস্করণে localStorage ব্যবহার করে অর্ডার/স্টক সংরক্ষণ হয়। Production ব্যবহারের আগে cloud database, authentication, backup এবং secure customer access যোগ করা উচিত।
