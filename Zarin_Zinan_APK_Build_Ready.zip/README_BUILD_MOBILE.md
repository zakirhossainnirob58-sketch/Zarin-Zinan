# Zarin & Zinan — Mobile APK Build

This project is configured for Android Gradle Plugin 8.7.3 and compile/target SDK 35.

## Easiest mobile build route
1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Zarin & Zinan APK**.
4. Tap **Run workflow** (or push to `main`).
5. When the workflow finishes, open the run and download the **Zarin-Zinan-debug-apk** artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

The workflow installs Gradle 8.9 automatically, so the project does not need a Gradle Wrapper in the ZIP.

## Current app scope
The app is a WebView wrapper around `app/src/main/assets/index.html`. Data is stored with browser localStorage on the device. Cloud backup, admin login, and customer OTP login are not included yet.
